from plugins.hidden_import import *

def search_for_updates():
    clear()
    setTitle("Hidden Checking For Updates. . .")
    
    try:
        latest_version_url = LAST_VERSION
        r = requests.get(latest_version_url)
        latest_version = r.text.strip()
    except:
        latest_version = THIS_VERSION

    if THIS_VERSION != latest_version:
        setTitle("New Update Found!")
        print(
            f"""
                ███╗   ██╗███████╗██╗    ██╗    ██╗   ██╗██████╗ ██████╗  █████╗ ████████╗███████╗  ██╗
                ████╗  ██║██╔════╝██║    ██║    ██║   ██║██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔════╝  ██║
                ██╔██╗ ██║█████╗  ██║ █╗ ██║    ██║   ██║██████╔╝██║  ██║███████║   ██║   █████╗    ██║
                ██║╚██╗██║██╔══╝  ██║███╗██║    ██║   ██║██╔═══╝ ██║  ██║██╔══██║   ██║   ██╔══╝    ╚═╝
                ██║ ╚████║███████╗╚███╔███╔╝    ╚██████╔╝██║     ██████╔╝██║  ██║   ██║   ███████╗  ██╗
                ╚═╝  ╚═══╝╚══════╝ ╚══╝╚══╝      ╚═════╝ ╚═╝     ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝  ╚═╝
                              Looks like Hidden {THIS_VERSION} is outdated """.replace(
                "█", f"█"
            ),
            end="\n\n",
        )

        update_url = LAST_VERSION_ZIP
        choice = input(
            f"[>>>] Do you want to update to the latest version? (Y to update N to continue using this version): "
        )

        if choice.lower() == "y" or choice.lower() == "yes":
            try:
                print(f"\nUpdating. . .")
                setTitle(f"Hidden Updating...")
                new_version_source = requests.get(update_url)
                with open("Hidden.zip", "wb") as zipfile:
                    zipfile.write(new_version_source.content)
                with ZipFile("Hiddden.zip", "r") as filezip:
                    filezip.extractall()
                os.remove("Hidden.zip")
                cwd = os.getcwd() + "\\Hidden"
                shutil.copytree(cwd, os.getcwd(), dirs_exist_ok=True)
                shutil.rmtree(cwd)
                setTitle("Hidden Update Complete!")
                print(f"Update Successfully Finished!")
                sleep(2)
                if os.path.exists(os.getcwd() + "setup.bat"):
                    os.startfile("setup.bat")
                elif os.path.exists(os.getcwd() + "start.bat"):
                    os.startfile("start.bat")
                os._exit(0)
            except:
                print_slow("Update failed")


def update():
    clear()
    setTitle("Hidden Checking For Updates. . .")

    setTitle("New Update Found!")
    print(
        f"""
        ██╗   ██╗██████╗ ██████╗  █████╗ ████████╗███████╗  ██╗
        ██║   ██║██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔════╝  ██║
        ██║   ██║██████╔╝██║  ██║███████║   ██║   █████╗    ██║
        ██║   ██║██╔═══╝ ██║  ██║██╔══██║   ██║   ██╔══╝    ╚═╝
        ╚██████╔╝██║     ██████╔╝██║  ██║   ██║   ███████╗  ██╗
         ╚═════╝ ╚═╝     ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝  ╚═╝
        Looks like your Hidden is outdated """.replace(
            "█", f"█"
        ),
        end="\n\n",
    )

    update_url = LAST_VERSION_ZIP
    choice = input(
        f"[>>>] Do you want to update to the latest dev branch (Remember that the dev branch might be unstable)?\n(Y to update N to continue using this version): "
    )

    if choice.lower() == "y" or choice.lower() == "yes":
        
        print(f"\nUpdating. . .")
        setTitle(f"Hidden Updating...")
        try:
            new_version_source = requests.get(update_url)
            with open("Hidden.zip", "wb") as zipfile:
                zipfile.write(new_version_source.content)
            with ZipFile("hidden.zip", "r") as filezip:
                filezip.extractall()
            os.remove("Hidden.zip")
            cwd = os.getcwd() + "\\Hidden"
            shutil.copytree(cwd, os.getcwd(), dirs_exist_ok=True)
            shutil.rmtree(cwd)
            setTitle("Hidden Update Complete!")
            print(f"Update Successfully Finished!")
            sleep(2)
            if os.path.exists(os.getcwd() + "setup.bat"):
                os.startfile("setup.bat")
            elif os.path.exists(os.getcwd() + "start.bat"):
                os.startfile("start.bat")
            os._exit(0)
        except:
            setTitle("Hidden Update Failed!")
            print(f"Update failed")
            sleep(2)
            input("Press Enter To Exit!")
            os._exit(0)

def check_version():
        try:
            assert sys.version_info >= (3,7)
        except AssertionError:
            print(f"Woopsie daisy, your Python version ({sys.version_info[0]}.{sys.version_info[1]}.{sys.version_info[2]}) is not compatible with Hidden, please download Python 3.7+")
            sleep(5)
            print("exiting. . .")
            sleep(1.5)
            os._exit(0)

def CHANGE_LOG():
    input(f'''{UPDATE}''')
