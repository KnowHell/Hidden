from plugins.hidden_import import *

def notfree():
    print_slow(f'''This feature is not availabe on the free version of Hidden\n check {SITE} and or {DISCORD} to buy the premium version!''')
    sleep(1.5)

def redirect(): 
    redirect = input(f'''Do you want to redirect to {SITE} and {DISCORD} ? (y/n): ''')
    if redirect.lower() == 'y':
        webbrowser.open(SITE)
        webbrowser.open(DISCORD)
    elif redirect.lower() == 'n':
        print("Redirect not requested.")
    else:
        print("Invalid input. Redirect not requested.")