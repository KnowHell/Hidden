from plugins.hidden_import import *

def setTitle(_str):
    system = os.name
    if system == 'nt':
        #if its windows
        ctypes.windll.kernel32.SetConsoleTitleW(f"{_str} | Made By </> Hidden")
    elif system == 'posix':
        #if its linux
        os.system(f"\033]0;{_str} | Made By </> Hidden\a", end='', flush=True)
    else:
        #if its something else or some err happend for some reason, we do nothing
        pass

def clear():
    system = os.name
    if system == 'nt':
        #if its windows
        os.system('cls')
    elif system == 'posix':
        #if its linux
        os.system('clear')
    else:
        print('\n'*120)
    return

