THIS_VERSION = "1.0.0"
SITE = "https://hiddenvirus.com"
DISCORD = "https://discord.gg/hiddenvirus"
UPDATE = '''
1. New HUD
2. New Theme
'''
LAST_VERSION = "https://github.com/KnowHell/Hidden/blob/main/latest_version.txt"
LAST_VERSION_ZIP = f"https://github.com/KnowHell/Hidden/blob/main/hidden.zip"
