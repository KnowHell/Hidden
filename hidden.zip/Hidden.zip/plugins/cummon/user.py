from plugins.hidden_import import *

def get_username():
    temp_dir = tempfile.gettempdir()
    
    username_file = os.path.join(temp_dir, 'Hidden_username')

    if os.path.isfile(username_file):
        with open(username_file, 'r') as f:
            username = f.read().strip()
    else:
        clear()
        usernamelogo()
        username = input(f"""Your Username: """)
        
        with open(username_file, 'w') as f:
            f.write(username)
    
    return username

username = get_username()

def setUsername(new: str):
    temp_dir = tempfile.gettempdir()
    username_file = os.path.join(temp_dir, 'Hidden_username')

    with open(username_file, 'w') as f:
        f.write(new)