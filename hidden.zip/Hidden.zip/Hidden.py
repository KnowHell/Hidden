from plugins.hidden_import import *

threads = 3
cancel_key = "ctrl+x"

def main():
    setTitle(f"</> Hidden {THIS_VERSION}")
    clear()
    global threads
    global cancel_key
    if getTheme() == "</>":
        banner()
    elif getTheme() == "dark":
        banner("dark")

    choice = input(f'[>>>] {username}: ').lstrip("0")
    choice = choice.upper()

    if choice == '?':
        CHANGE_LOG()
        main()

    elif choice == 'TM':
        print(f"""                                            Development Networks:\n\n                                                GitHub:    @KnowHell\n\n\n                                            Other Networks\n\n                                                Discord:   @knowell, @siczy.\n\n\n\n""")
        input("Press Enter To Exit!")
        main()

    elif choice == 'UPD':
        print(update())

    elif choice == 'BUY':
        redirect()
        main
        
    elif choice == '!':
        print(f'''
        [1] Theme changer
        [2] Change Username
        [3] Amount of threads
        [4] Cancel key
        [5] Exit...    
                        ''')
        secondchoice = input(
            f'[>>>] Setting: ')
        if secondchoice not in ["1", "2", "3", "4", "5"]:
            print(f'[Error] : Invalid Setting')
            sleep(1)
            main()
        if secondchoice == "1":
            print(f"""
        </>: 1
        Dark: 2
        """)
            themechoice = input(
                f'[>>>] theme: ')
            if themechoice == "1":
                setTheme('</>')
            elif themechoice == "2":
                setTheme('dark')
            else:
                print(f'[Error] : Invalid Theme')
                sleep(1.5)
                main()
            print_slow(f"Theme set to {getTheme()}")
            sleep(0.5)
            main()

        elif secondchoice == "2":
            new_username = input(f'Enter your new username: ')
            setUsername(new_username)
            print_slow(f"Username set to {new_username}\nRestarting tool")
            sleep(2)
            subprocess.run("start.bat", shell=True)
            exit()


        elif secondchoice == "3":
            print(f"Current amount of threads: {threads}")
            try:
                amount = int(
                    input(f'[>>>] Amount of threads: '))
            except ValueError:
                print(f'[Error] : Invalid amount')
                sleep(1.5)
                main()
            if amount >= 45:
                print(f"Sorry but having this many threads will just get you ratelimited and not end up well")
                sleep(3)
                main()
            elif amount >= 15:
                print(f"WARNING! * WARNING! * WARNING! * WARNING! * WARNING! * WARNING! * WARNING!")
                print(f"having the thread amount set to 15 or over can possible get laggy and higher chance of ratelimit\nare you sure you want to set the ratelimit to {amount}?")
                yesno = input(f'[>>>] yes/no: ')
                if yesno.lower() != "yes":
                    sleep(0.5)
                    main()
            threads = amount
            print_slow(f"Threads set to {amount}")
            sleep(0.5)
            main()
        
        elif secondchoice == "4":
            print("\n","Info".center(30, "-"))
            print(f"Current cancel key: {cancel_key}")
            print(f"""If you want to have ctrl + <key> you need to type out ctrl+<key> | DON'T literally press ctrl + <key>
        Example: shift+Q

        You can have other modifiers instead of ctrl ⇣
        All keyboard modifiers:
        ctrl, shift, enter, esc, windows, left shift, right shift, left ctrl, right ctrl, alt gr, left alt, right alt
        """)
            sleep(1.5)
            key = input(f'[>>>] Key: ')
            cancel_key = key
            print_slow(f"Cancel key set to {cancel_key}")
            sleep(0.5)
            main()

        elif secondchoice == "5":
            setTitle("Exiting. . .")
            choice = input(
                f'[>>>] Are you sure you want to exit? (Y to confirm): ')
            if choice.upper() == 'Y':
                clear()
                os._exit(0)
            else:
                main()
    else:
        clear()
        main()

if __name__ == "__main__":
    import sys
    setTitle("Hidden Loading...")
    System.Size(120, 28)
    search_for_updates()
    get_username()
    Anime.Fade(Center.Center(startuplogo), Colors.rainbow, Colorate.Vertical, time=2)
    check_version()
    proxy_file = os.getenv("temp") + "\\Hidden_proxies"
    if not os.path.exists(proxy_file):
        proxy_scrape()
    with open(os.getenv("temp") + "\\Hidden_proxies", 'w'):
        pass
    if not os.path.exists(os.getenv("temp") + "\\Hidden_theme"):
        setTheme('</>')
    sleep(1.5)
    main()

